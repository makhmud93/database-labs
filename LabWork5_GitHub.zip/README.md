# Lab Work 5 — Database Constraints

**Course topic:** PostgreSQL database constraints  
**Language:** SQL (PostgreSQL)  
**Comments and explanations:** Russian

## Contents

- `LabWork5_solution.sql` — complete solution for Parts 1–6.
- `.gitignore` — excludes common temporary files.

## Requirements

- PostgreSQL 12 or newer (the script uses standard PostgreSQL features).
- pgAdmin, DBeaver, or `psql` to run the SQL script.

## How to run

1. Open `LabWork5_solution.sql` in pgAdmin or another PostgreSQL client.
2. Update the student name and student ID at the top of the file.
3. Run the script in a **test/learning database**. The script drops and recreates tables with the same names, so do not run it in a database containing important data.
4. The invalid `INSERT` and `DELETE` examples are commented out so the full script can run without stopping. Uncomment and run each test separately to demonstrate the constraint violation, then comment it again.

## Parts covered

1. `CHECK` constraints
2. `NOT NULL` constraints
3. `UNIQUE` constraints
4. `PRIMARY KEY` constraints
5. `FOREIGN KEY` constraints, including `ON DELETE RESTRICT` and `ON DELETE CASCADE`
6. E-commerce database schema with sample data and test queries

## Notes

- Each of the four e-commerce tables has at least five sample rows.
- The script includes verification queries for row counts, order summaries, and totals.
- The SQL script has been prepared, but run it in your own PostgreSQL environment and check the output before submitting.

## Repository setup

Upload these files to a new GitHub repository. Suggested repository name: `database-lab5-constraints`.
